import pandas as pd
from datetime import datetime
data = pd.read_csv('sphist.csv')
data['Date'] = pd.to_datetime(data['Date'])
mask = data["Date"] > datetime(year=2015, month=4, day=1)
data = data.sort_values("Date", ascending = True)
data['day_5'] = data['Close'].rolling(5).mean()
data['day_5_std'] = data['Close'].rolling(5).std()
data['day_30_std'] = data['Close'].rolling(30).std()
data['day_5v'] = data['Volume'].rolling(5).mean()
data['day'] = data['Date'].dt.dayofweek
# print(data[['Date','day_5','day_5_std','day_30_std']].head(30))
data['Date'] = data['Date'].shift(-1)
# print(data[['Date','day_5','day_5_std','day_30_std']].head(30))
data = data.dropna(axis= 0)
data.info()
data = data[data["Date"] > datetime(year=1951, month=1, day=2)]
train = data[data["Date"] < datetime(year=2013, month=1, day=1)]
test = data[data["Date"] >= datetime(year=2013, month=1, day=1)]
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
lr = LinearRegression()
lr.fit(train[['day_5','day_5_std','day_30_std','day_5v','day']], train[['Close']])
predictions = lr.predict(test[['day_5','day_5_std','day_30_std','day_5v','day']])
mse = mean_squared_error(predictions, test[['Close']]) **(1/2)
print(mse)



